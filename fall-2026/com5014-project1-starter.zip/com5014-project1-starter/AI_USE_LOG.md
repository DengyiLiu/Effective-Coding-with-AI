# AI use log

Log meaningful AI use: generating code, designing tools, debugging, writing tests, drafting docs.
Skip trivia (autocomplete of one line). The evaluation runs themselves are logged in EVAL.md, not here.

| Date | Tool + model | What I asked for | What I kept / changed / rejected, and why |
|---|---|---|---|
| | | | |
