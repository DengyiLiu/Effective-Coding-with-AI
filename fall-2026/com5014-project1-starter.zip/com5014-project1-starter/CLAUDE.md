@AGENTS.md

## Claude Code only
- Use plan mode before changing more than one file.
