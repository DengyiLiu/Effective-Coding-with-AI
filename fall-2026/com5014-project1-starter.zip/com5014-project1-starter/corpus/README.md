`papers.json` is created by `tools/fetch_corpus.py`. Each paper:

```json
{"id": "2401.18059", "title": "...", "authors": ["..."], "year": 2024, "published": "2024-01-31",
 "primary_category": "cs.CL", "categories": ["cs.CL"], "abstract": "...", "url": "https://arxiv.org/abs/2401.18059"}
```
Your decoy is added with `tools/add_decoy.py`. Do not change this file once you start the baseline runs.
