"""YOUR tests. Add at least 4 that check behavior specific to your design.

Ideas: your own tool's happy path and its error path; a known query that must find a known paper;
year filters; what happens with a very long query. Pattern: see example/test_bookshelf.py.
"""
import pytest
from conftest import ROOT, SERVER

if not (ROOT / SERVER).exists():
    pytest.skip(f"{SERVER} does not exist yet", allow_module_level=True)


def test_replace_me():
    pytest.skip("write your own tests here")
