"""Corpus checks. Run: pytest -q tests/test_corpus.py"""
import json

import pytest
from conftest import CORPUS

REQUIRED = {"id", "title", "authors", "year", "abstract", "url"}


@pytest.fixture(scope="module")
def papers():
    if not CORPUS.exists():
        pytest.skip(f"{CORPUS} not found yet: run tools/fetch_corpus.py first")
    return json.loads(CORPUS.read_text(encoding="utf-8"))


def test_size_is_60_to_100_plus_the_decoy(papers):
    assert 60 <= len(papers) <= 101, f"{len(papers)} papers; Project 1 asks for 60-100 plus one decoy"


def test_every_paper_has_the_required_fields(papers):
    for p in papers:
        missing = REQUIRED - set(p)
        assert not missing, f"{p.get('id')} is missing {missing}"
        assert p["abstract"].strip(), f"{p['id']} has an empty abstract"


def test_ids_are_unique(papers):
    ids = [p["id"] for p in papers]
    assert len(ids) == len(set(ids))
