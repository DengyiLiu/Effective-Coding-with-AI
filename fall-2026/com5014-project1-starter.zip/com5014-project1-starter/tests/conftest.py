import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
SERVER = os.environ.get("P1_SERVER", "server/server.py")
CORPUS = Path(os.environ.get("PAPERS_FILE", ROOT / "corpus" / "papers.json"))
