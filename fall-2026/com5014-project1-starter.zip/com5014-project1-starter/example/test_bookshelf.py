"""Tests for the example server. Same style you will use for yours: no LLM, just MCP calls."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
from mcp_helpers import result_data, result_text, run  # noqa: E402

SERVER = "example/bookshelf_server.py"


def test_tools_are_listed_and_read_only():
    async def go(c):
        return {t.name: t for t in (await c.list_tools()).tools}
    tools = run(SERVER, go)
    assert {"search_books", "get_book"} <= set(tools)
    assert all(t.annotations and t.annotations.read_only_hint for t in tools.values())


def test_search_finds_a_known_book():
    async def go(c):
        return await c.call_tool("search_books", {"query": "legacy code tests"})
    r = run(SERVER, go)
    assert not r.is_error
    assert "B005" in [h["id"] for h in result_data(r)]


def test_search_rejects_a_query_with_no_real_words():
    async def go(c):
        return await c.call_tool("search_books", {"query": "a b"})
    r = run(SERVER, go)
    assert r.is_error and "3+ letters" in result_text(r)


def test_get_book_unknown_id_explains_how_to_recover():
    async def go(c):
        return await c.call_tool("get_book", {"book_id": "B999"})
    r = run(SERVER, go)
    assert r.is_error and "search_books" in result_text(r)


def test_get_book_rejects_malformed_id_before_running():
    async def go(c):
        return await c.call_tool("get_book", {"book_id": "pragmatic"})
    assert run(SERVER, go).is_error


def test_index_resource_lists_every_book():
    async def go(c):
        return await c.read_resource("books://index")
    r = run(SERVER, go)
    assert r.contents[0].text.count("\n") == 7
