"""Example MCP server: a read-only bookshelf.

This is a PATTERN to copy, not your project. Your server works on papers, not books.
It shows the four habits Project 1 grades:
  1. Typed, constrained parameters (Annotated + Field) -> the model sees the limits.
  2. ToolError with a message that tells the model how to fix its call.
  3. Read-only annotations, so the host knows these tools change nothing.
  4. Data loaded from a file whose path comes from an environment variable.

Run its tests:  pytest -q example
Inspect it:     python tools/check_server.py example/bookshelf_server.py
"""
import json
import os
from pathlib import Path
from typing import Annotated

from pydantic import Field

from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.types import ToolAnnotations

DATA = Path(os.environ.get("BOOKSHELF_DATA", Path(__file__).with_name("books.json")))
BOOKS = {b["id"]: b for b in json.loads(DATA.read_text(encoding="utf-8"))}
READ_ONLY = ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=False)

mcp = MCPServer("bookshelf")


@mcp.tool(annotations=READ_ONLY)
def search_books(
    query: Annotated[str, Field(min_length=1, max_length=100, description="Words to look for in titles and summaries.")],
    limit: Annotated[int, Field(ge=1, le=10, description="How many results to return.")] = 5,
) -> list[dict]:
    """Find books whose title or summary contains any of the query words.

    Returns the best matches first, as {id, title, year, matched_words}.
    Results are keyword matches, not guaranteed answers: open a book with get_book before quoting it.
    """
    words = {w for w in query.lower().split() if len(w) > 2}
    if not words:
        raise ToolError("Query needs at least one word of 3+ letters, e.g. 'testing legacy code'.")
    hits = []
    for b in BOOKS.values():
        text = f"{b['title']} {b['summary']}".lower()
        matched = sorted(w for w in words if w in text)
        if matched:
            hits.append({"id": b["id"], "title": b["title"], "year": b["year"], "matched_words": matched})
    hits.sort(key=lambda h: -len(h["matched_words"]))
    return hits[:limit]


@mcp.tool(annotations=READ_ONLY)
def get_book(
    book_id: Annotated[str, Field(pattern=r"^B\d{3}$", description="Book ID such as B004.")],
) -> dict:
    """Return one book's full record. Use the IDs returned by search_books."""
    if book_id not in BOOKS:
        raise ToolError(f"No book {book_id}. Call search_books first, or read books://index for all IDs.")
    return BOOKS[book_id]


@mcp.resource("books://index")
def index() -> str:
    """Every book ID and title, one per line."""
    return "\n".join(f"{b['id']}  {b['title']} ({b['year']})" for b in BOOKS.values())


if __name__ == "__main__":
    mcp.run(transport="stdio")  # never print() to stdout in a stdio server: it corrupts the protocol
