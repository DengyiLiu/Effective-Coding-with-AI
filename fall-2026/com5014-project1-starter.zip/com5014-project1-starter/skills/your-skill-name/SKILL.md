---
name: your-skill-name
description: <WHEN to use this skill, in one or two sentences. This is what the agent reads to decide. Name the trigger situations, and say what it is NOT for.>
---

# <Skill title>

<!-- Week 4: the skill is the METHOD. The server is the ACCESS. Keep this file short;
     put long material in files next to it (a template, a checklist, an example). -->

## When to use
-

## When NOT to use
-

## Procedure
1.
2.
3.

## Rules
- Cite only paper IDs that a tool returned in this session.
-

## Output format
See `template.md` (or describe it here).

## If something goes wrong
- No relevant paper found:
- A tool returns an error:
