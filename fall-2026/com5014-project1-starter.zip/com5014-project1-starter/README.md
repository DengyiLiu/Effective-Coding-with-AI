# COM 5014 Project 1 starter: "Prove It"

You will build a paper assistant for your own research topic (a corpus, a Skill, an MCP server)
and prove with evidence what each piece adds. The full brief is the Project 1 handout on Canvas.

## Quick start (10 minutes)
```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -c "from mcp.server import MCPServer"     # prints nothing. ImportError = old mcp 1.x: use a fresh venv
pytest                                           # expect: 6 passed, the rest skipped
python tools/check_server.py example/bookshelf_server.py
```

## 1. Build your corpus
```bash
python tools/fetch_corpus.py --query 'abs:"your topic" AND cat:cs.XX' --max 80
python tools/add_decoy.py --title "..." --abstract-file decoy.txt
pytest tests/test_corpus.py
```

## 2. Spec, review, baseline
Fill `SPEC.md`, review it in a fresh AI session with `SPEC_REVIEW_PROMPT.md`,
save the review to `evidence/spec_review.md`, and run condition A (see `EVAL.md`).

## 3. Your skill (after your spec review)
Rename `skills/your-skill-name/` and fill `SKILL.md` plus one supporting file.

## 4. Your server
Write `server/server.py` (with your coding agent, from your reviewed SPEC.md). Copy the habits in
`example/bookshelf_server.py`. Then:
```bash
pytest                                            # the contract tests must all pass
python tools/check_server.py server/server.py
python tools/check_server.py server/server.py search_papers '{"query": "your words", "k": 3}'
python tools/retrieval_eval.py server/server.py --out evidence/retrieval_eval.md
```

Connect it to your agent with **absolute paths**:
```bash
claude mcp add paper-library -- /ABS/PATH/.venv/bin/python /ABS/PATH/server/server.py
codex  mcp add paper-library -- /ABS/PATH/.venv/bin/python /ABS/PATH/server/server.py
# Windows interpreter: C:\ABS\PATH\.venv\Scripts\python.exe
```

## 5. Evaluate
Make a run folder OUTSIDE this repo (see EVAL.md). After the runs:
```bash
python tools/check_citations.py evidence/runs/*.md --decoy 9999.00001
```

## Files
| File | Step | What |
|---|---|---|
| `SPEC.md` | 2 | Topic, tasks, acceptance criteria, design split, tool design, risks |
| `SPEC_REVIEW_PROMPT.md` | 2 | Paste into a fresh AI session to review your spec; save the answer to `evidence/spec_review.md` |
| `AGENTS.md`, `CLAUDE.md` | 2 | Rules for the coding agent that builds your project |
| `corpus/papers.json` | 1 | Your 60-100 papers + 1 decoy |
| `EVAL.md` | 2 → 5 | Baseline (A) before you build, then B, C, D |
| `skills/your-skill-name/` | 3 | Your skill (rename the folder) |
| `server/server.py` | 4 | Your MCP server |
| `tests/test_contract.py` | — | The required contract. Do not edit |
| `tests/test_my_server.py` | 4 | Your own tests (at least 4) |
| `eval/retrieval_questions.csv` | 4 | 10+ questions with the IDs that should come back |
| `evidence/` | all | Saved answers, screenshots, eval output |
| `AI_USE_LOG.md` | all | Meaningful AI use |

## Gotchas we hit while testing
- Changed the server? **Restart the agent session** so it reconnects.
- Never `print()` in `server/server.py`: stdout is the protocol channel. Log to stderr.
- Run evaluation sessions from a folder that does **not** contain your source code,
  or the agent reads the code instead of using the tools.
- `fetch_corpus.py` refuses to overwrite `corpus/papers.json` (your decoy would be lost). Use `--force` on purpose.
