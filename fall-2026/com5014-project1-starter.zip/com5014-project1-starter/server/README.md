Your MCP server goes in `server/server.py`. The contract (checked by `tests/test_contract.py`):

| Must have | Requirement |
|---|---|
| `search_papers(query, k)` | read-only; `k` limited to 1-10; returns a list of `{id, title, ...}` best first; survives punctuation; blank query is an error |
| `get_paper(paper_id)` | read-only; returns the corpus record; unknown ID -> `ToolError` that says what to do next |
| one more tool | your own design, justified in SPEC.md |
| `papers://index` | resource listing every paper ID |

Load the corpus from `corpus/papers.json` relative to the repo (or the `PAPERS_FILE` environment variable).
