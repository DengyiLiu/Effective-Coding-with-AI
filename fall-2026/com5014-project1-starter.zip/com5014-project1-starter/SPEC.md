# SPEC.md: Project 1 (write and review this before you build)

> Week 6 rule: spec first, review, then build. Be specific enough that a classmate could build
> from this file. Before you build, review it with SPEC_REVIEW_PROMPT.md in a fresh AI session,
> fix what it finds, and save the review to evidence/spec_review.md.

## 1. Topic and user
- **Topic** (one line):
- **Who would use this assistant, and for what?** (e.g. "me, writing the related-work section of my thesis proposal")
- **arXiv query you used** (exact string) and **number of papers**:
- **Three paper IDs you recognize** as clearly on-topic (proof you looked at the corpus):

## 2. The workflow today
How would you do this without AI, step by step? Where does it hurt?

| Step | What happens | Pain point |
|---|---|---|
| 1 | | |

## 3. Task set (6 tasks, exact wording)
Write these NOW. You will type exactly these words in every evaluation run.

| ID | Exact prompt | Type | Acceptance criteria (checkable by someone else) |
|---|---|---|---|
| T1 | | core | |
| T2 | | core | |
| T3 | | core | |
| T4 | | core | |
| T5 | | no answer in corpus | Says the library has no paper on this; cites nothing invented |
| T6 | | out of scope | The skill does NOT trigger; the answer does not use the paper tools |

Good acceptance criteria are checkable: "cites at least 3 papers, every ID exists in the corpus,
each claim matches the cited abstract" — not "a good summary".

## 4. Design split
For each capability the agent needs, choose where it lives and say why (Week 5, S17).

| Capability | Prompt / AGENTS.md / Skill / Skill file / MCP tool / MCP resource | Why there |
|---|---|---|
| Find candidate papers for a question | | |
| Read one paper's abstract | | |
| Know how a good related-work brief is structured | | |
| Never cite an ID it did not retrieve | | |
| | | |

**Why does this need an MCP server at all,** when the agent could just read `papers.json`?
(Your A/B runs will test your answer.)

## 5. Tool design draft
| Name | Parameters (type + limits) | Description, as the model will read it | Read-only? |
|---|---|---|---|
| `search_papers` | `query: str (1-300)`, `k: int (1-10)` | | yes |
| `get_paper` | `paper_id: str` | | yes |
| your tool: | | | yes |

What does the model see when it calls each tool with bad input? Write one error message here:

## 6. The decoy
- Decoy ID:
- The harmless hidden instruction (paste it):
- Which of your tasks is likely to retrieve it?

## 7. Risks
| Risk | How you will notice | What you will do |
|---|---|---|
| | | |
