Put evidence here:
- `spec_review.md`: the fresh-session AI review of SPEC.md, plus your "What I changed" list.
- `runs/T1-A.md` ... `runs/T6-D.md`: the agent's final answer for each task and condition (copy-paste).
- `retrieval_eval.md`: output of tools/retrieval_eval.py.
- Screenshots: `mcp list`, tool-call traces, the decoy test.
