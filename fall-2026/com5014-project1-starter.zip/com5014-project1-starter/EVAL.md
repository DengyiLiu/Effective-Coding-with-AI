# EVAL.md

## 1. Setup (fill once, keep it the same for every run)
- Agent + version (e.g. Codex CLI x.y / Claude Code x.y):
- Model:
- Run folder (outside this repo):
- Date(s):

The four conditions. Everything else stays the same.

| Condition | Skill installed | MCP server connected | `papers.json` in the run folder |
|---|---|---|---|
| A: bare agent | no | no | yes |
| B: skill only | yes | no | yes |
| C: server only | no | yes | no |
| D: skill + server | yes | yes | no |

Rules: a **fresh session for every run** (Week 3). Type the task prompt from SPEC.md exactly.
Save the final answer to `evidence/runs/<task>-<condition>.md`. Don't retry a bad run: record it.

## 2. Results (24 runs)
Pass = meets every acceptance criterion in SPEC.md. Fill `fake IDs` from `tools/check_citations.py`.

| Task | Cond. | Pass? | Real IDs cited | Fake IDs | Tool calls / files read | Notes (what went right or wrong) |
|---|---|---|---|---|---|---|
| T1 | A | | | | | |
| T1 | B | | | | | |
| T1 | C | | | | | |
| T1 | D | | | | | |
| T2 | A | | | | | |
| ... | | | | | | |

Summary: passes per condition: A __/6, B __/6, C __/6, D __/6.

## 3. Retrieval, scored separately (Week 7)
Paste `evidence/retrieval_eval.md` totals here: hit@3 = __/__, MRR@3 = __.
Then: one question where retrieval failed, and what happened to the agent's answer on the task that depended on it.

## 4. Decoy test
- Decoy ID:
- Prompt used:
- Conditions where the decoy was retrieved / cited / **its instruction was followed**:
- What in your setup helped or failed (tool description, skill rule, nothing)?

## 5. What each piece added (the point of the project)
Answer with evidence from sections 2-4 (cite rows). Half a page each, at most.
1. What did the **skill** change? (compare A→B and C→D)
2. What did the **server** change? (compare A→C and B→D) Did your tool beat plain file reading?
3. What did **neither** fix?
4. **One change you made after seeing results**, and the rerun that shows its effect (before → after rows).
