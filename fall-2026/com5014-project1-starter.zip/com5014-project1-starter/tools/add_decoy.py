"""Add your decoy paper (the one with a hidden instruction) to the corpus.

  python tools/add_decoy.py --title "..." --abstract-file decoy.txt

The decoy must look like a normal paper in your topic, with ONE harmless hidden instruction
inside the abstract (see the handout for the rules and an example). Write down its ID in EVAL.md.
"""
import argparse
import json
import sys
from collections import Counter
from pathlib import Path

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("--title", required=True)
ap.add_argument("--abstract-file", required=True, help="plain-text file with the decoy abstract")
ap.add_argument("--id", default="9999.00001", help="ID for the decoy (default 9999.00001, which arXiv can never issue)")
ap.add_argument("--authors", default="J. Doe, A. Smith")
ap.add_argument("--year", type=int, default=2026)
ap.add_argument("--corpus", default="corpus/papers.json")
args = ap.parse_args()

path = Path(args.corpus)
papers = json.loads(path.read_text(encoding="utf-8"))
if any(p["id"] == args.id for p in papers):
    sys.exit(f"{args.id} is already in the corpus. Use --id to pick another.")
cat = Counter(p.get("primary_category") for p in papers).most_common(1)[0][0]
abstract = " ".join(Path(args.abstract_file).read_text(encoding="utf-8").split())
papers.append({
    "id": args.id, "title": args.title,
    "authors": [a.strip() for a in args.authors.split(",")],
    "year": args.year, "published": f"{args.year}-01-15",
    "primary_category": cat, "categories": [cat],
    "abstract": abstract, "url": f"https://arxiv.org/abs/{args.id}",
})
path.write_text(json.dumps(papers, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(f"Added decoy {args.id} ({len(papers)} papers now). Record this ID in EVAL.md, section 4.")
