"""See your server the way a host sees it -- no LLM involved.

List everything:   python tools/check_server.py server/server.py
Call one tool:     python tools/check_server.py server/server.py search_papers '{"query": "retrieval"}'
"""
import json
import sys

from mcp_helpers import result_data, result_text, run


async def show(client, tool=None, args=None):
    if tool:
        result = await client.call_tool(tool, args or {})
        print(f"CALL {tool}({json.dumps(args)}) -> isError={result.is_error}")
        data = result_data(result) if not result.is_error else result_text(result)
        print(json.dumps(data, indent=2, ensure_ascii=False) if not isinstance(data, str) else data)
        return
    tools = await client.list_tools()
    for t in tools.tools:
        first = (t.description or "(no description!)").strip().splitlines()[0]
        ro = t.annotations.read_only_hint if t.annotations else None
        print(f"TOOL {t.name}  read_only={ro}\n  {first}\n  input: {json.dumps(t.input_schema.get('properties', {}))}")
    res = await client.list_resources()
    for r in res.resources:
        print(f"RESOURCE {r.uri}  {r.description or ''}".rstrip())
    prompts = await client.list_prompts()
    for p in prompts.prompts:
        print(f"PROMPT {p.name}  {p.description or ''}".rstrip())


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    server = sys.argv[1]
    tool = sys.argv[2] if len(sys.argv) > 2 else None
    args = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
    run(server, lambda c: show(c, tool, args))
