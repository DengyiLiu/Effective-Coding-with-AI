"""Download arXiv titles + abstracts into corpus/papers.json (run once, then everything is offline).

Examples (quotes matter):
  python tools/fetch_corpus.py --query 'abs:"diffusion model" AND cat:cs.CV' --max 80
  python tools/fetch_corpus.py --query 'ti:"graph neural network" AND abs:drug' --max 60
  python tools/fetch_corpus.py --query 'all:"federated learning"' --max 100 --since 2022

Query syntax (arXiv API): ti: title, abs: abstract, au: author, cat: category (cs.CL, cs.LG, stat.ML ...),
all: everything. Combine with AND / OR / ANDNOT. Put phrases in double quotes.
Test your query first in the browser: https://arxiv.org/search/advanced

Only metadata (title, authors, abstract, dates, categories) is stored. arXiv metadata is CC0.
"""
import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

API = "https://export.arxiv.org/api/query"
NS = {"a": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}
PAGE = 50          # arXiv asks for small pages ...
PAUSE = 3.0        # ... and 3 seconds between requests
ID_RE = re.compile(r"arxiv\.org/abs/(.+?)(v\d+)?$")


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def parse(xml_text: str) -> list[dict]:
    root = ET.fromstring(xml_text)
    papers = []
    for e in root.findall("a:entry", NS):
        raw_id = e.findtext("a:id", default="", namespaces=NS)
        m = ID_RE.search(raw_id)
        if not m:  # arXiv returns a single "Error" entry for a malformed query
            msg = clean(e.findtext("a:summary", default="", namespaces=NS))
            raise SystemExit(f"arXiv did not understand the query: {msg or raw_id}")
        pid = m.group(1)
        primary = e.find("arxiv:primary_category", NS)
        papers.append({
            "id": pid,
            "title": clean(e.findtext("a:title", default="", namespaces=NS)),
            "authors": [clean(a.findtext("a:name", default="", namespaces=NS)) for a in e.findall("a:author", NS)],
            "year": int(e.findtext("a:published", default="0000", namespaces=NS)[:4]),
            "published": e.findtext("a:published", default="", namespaces=NS)[:10],
            "primary_category": primary.get("term") if primary is not None else None,
            "categories": [c.get("term") for c in e.findall("a:category", NS)],
            "abstract": clean(e.findtext("a:summary", default="", namespaces=NS)),
            "url": f"https://arxiv.org/abs/{pid}",
        })
    return papers


def download(query: str, start: int, n: int) -> str:
    url = API + "?" + urllib.parse.urlencode({
        "search_query": query, "start": start, "max_results": n,
        "sortBy": "relevance", "sortOrder": "descending"})
    req = urllib.request.Request(url, headers={"User-Agent": "COM5014-course-project/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.read().decode("utf-8")
    except urllib.error.HTTPError as err:
        # arXiv answers a malformed query with HTTP 400 and an Atom "Error" entry: show its message.
        body = err.read().decode("utf-8", errors="replace")
        if body.lstrip().startswith("<?xml"):
            parse(body)  # raises SystemExit with arXiv's explanation
        raise SystemExit(f"arXiv returned HTTP {err.code}. Wait a minute and try again.")
    except (urllib.error.URLError, TimeoutError) as err:
        raise SystemExit(f"Could not reach arXiv ({err}). Check your internet connection and try again.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--query", help="arXiv search query (see examples above)")
    ap.add_argument("--max", type=int, default=80, help="number of papers to keep, 60-100 (default 80)")
    ap.add_argument("--since", type=int, default=None, help="keep only papers first published in or after this year")
    ap.add_argument("--out", default="corpus/papers.json")
    ap.add_argument("--from-xml", help="parse a saved arXiv API response instead of downloading (offline/testing)")
    ap.add_argument("--force", action="store_true", help="overwrite an existing corpus file")
    args = ap.parse_args()

    out = Path(args.out)
    if out.exists() and not args.force:
        sys.exit(f"{out} already exists. Add --force to replace it (your decoy paper will be lost).")
    if not 60 <= args.max <= 100:
        sys.exit("Project 1 asks for 60-100 papers. Use --max between 60 and 100.")

    papers: dict[str, dict] = {}
    if args.from_xml:
        for p in parse(Path(args.from_xml).read_text(encoding="utf-8")):
            papers.setdefault(p["id"], p)
    else:
        if not args.query:
            sys.exit("Give --query, e.g. --query 'abs:\"diffusion model\" AND cat:cs.CV'")
        start = 0
        # Ask for extra results: --since and duplicates remove some.
        while len(papers) < args.max and start < args.max * 3:
            batch = parse(download(args.query, start, PAGE))
            if not batch:
                break
            for p in batch:
                if args.since is None or p["year"] >= args.since:
                    papers.setdefault(p["id"], p)
            start += PAGE
            print(f"  fetched {start} results, kept {len(papers)}", file=sys.stderr)
            time.sleep(PAUSE)

    kept = list(papers.values())[: args.max]
    if len(kept) < 60 and not args.from_xml:
        sys.exit(f"Only {len(kept)} papers matched. Broaden the query (fewer AND terms, or drop --since).")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(kept, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    years = sorted(p["year"] for p in kept)
    print(f"Saved {len(kept)} papers to {out} (years {years[0]}-{years[-1]}).")
    print("Next: open the file, skim 10 titles. Off-topic? Refine the query and rerun with --force.")


if __name__ == "__main__":
    main()
