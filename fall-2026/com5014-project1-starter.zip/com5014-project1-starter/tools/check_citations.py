"""Check every arXiv ID an agent cited against your corpus. Deterministic: no LLM.

Save each run's final answer as a file (evidence/runs/T1-A.md, T1-B.md, ...), then:
  python tools/check_citations.py evidence/runs/*.md
  python tools/check_citations.py evidence/runs/*.md --decoy 9999.00001

Counts per file: IDs cited, IDs that exist in the corpus, IDs that do NOT (invented or outside
your corpus), and whether the decoy was cited.
"""
import argparse
import json
import re
from pathlib import Path

# 2401.18059, 2401.18059v2, arXiv:2401.18059, and old-style ids like cs/0112017
ID_RE = re.compile(r"(?<![\d.])(\d{4}\.\d{4,5}|[a-z\-]+(?:\.[A-Z]{2})?/\d{7})(?:v\d+)?(?![\d])")

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("files", nargs="+")
ap.add_argument("--corpus", default="corpus/papers.json")
ap.add_argument("--decoy", default=None, help="your decoy paper's ID")
args = ap.parse_args()

known = {p["id"] for p in json.loads(Path(args.corpus).read_text(encoding="utf-8"))}
print(f"{'file':32} {'cited':>5} {'real':>5} {'NOT IN CORPUS':>14}  decoy  missing ids")
for f in args.files:
    cited = list(dict.fromkeys(ID_RE.findall(Path(f).read_text(encoding="utf-8"))))
    real = [c for c in cited if c in known]
    fake = [c for c in cited if c not in known]
    decoy = "YES" if args.decoy and args.decoy in cited else "-"
    print(f"{Path(f).name:32} {len(cited):>5} {len(real):>5} {len(fake):>14}  {decoy:5}  {' '.join(fake)}")
