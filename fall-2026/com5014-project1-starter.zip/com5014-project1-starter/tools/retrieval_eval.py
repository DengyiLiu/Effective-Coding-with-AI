"""Score your search tool on its own, before any LLM is involved (Week 7: retrieval bounds the answer).

Fill eval/retrieval_questions.csv, then:
  python tools/retrieval_eval.py server/server.py
  python tools/retrieval_eval.py server/server.py --k 3 --out evidence/retrieval_eval.md

For each question: was a relevant paper in the top k (hit@k), and at what rank (reciprocal rank)?
Questions with an empty relevant_ids column are "no answer in the corpus" checks: they are listed
with what the tool returned, so you can see what your agent will be handed.
"""
import argparse
import csv
import sys

from mcp_helpers import result_data, result_text, run

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("server")
ap.add_argument("--questions", default="eval/retrieval_questions.csv")
ap.add_argument("--tool", default="search_papers")
ap.add_argument("--k", type=int, default=3)
ap.add_argument("--out", default=None, help="also write the table as Markdown to this file")
args = ap.parse_args()

with open(args.questions, newline="", encoding="utf-8") as fh:
    rows = [r for r in csv.DictReader(fh) if r.get("question", "").strip() and not r["qid"].startswith("#")]
if not rows:
    sys.exit(f"No questions in {args.questions}. Add at least 10 rows first.")


async def search_all(client):
    out = []
    for r in rows:
        res = await client.call_tool(args.tool, {"query": r["question"], "k": args.k})
        out.append(("ERROR: " + result_text(res)) if res.is_error else result_data(res))
    return out


results = run(args.server, search_all)
lines = [f"| qid | question | relevant | top {args.k} returned | hit@{args.k} | RR |", "|---|---|---|---|---|---|"]
hits, rr_sum, scored = 0, 0.0, 0
for r, res in zip(rows, results):
    relevant = [x.strip() for x in r["relevant_ids"].split(";") if x.strip()]
    if isinstance(res, str):
        got, hit, rr = res, "error", 0.0
    else:
        ids = [h["id"] for h in res]
        got = ", ".join(ids) or "(nothing)"
        rank = next((i + 1 for i, x in enumerate(ids) if x in relevant), None)
        hit = "-" if not relevant else ("yes" if rank else "no")
        rr = (1 / rank) if rank else 0.0
    if relevant:
        scored += 1
        hits += hit == "yes"
        rr_sum += rr
    lines.append(f"| {r['qid']} | {r['question']} | {'; '.join(relevant) or '(none in corpus)'} | {got} | {hit} | "
                 f"{rr:.2f} |" if relevant else f"| {r['qid']} | {r['question']} | (none in corpus) | {got} | - | - |")
summary = (f"\nhit@{args.k}: {hits}/{scored} = {hits / scored:.2f}   MRR@{args.k}: {rr_sum / scored:.2f}"
           if scored else "\n(no scored questions)")
table = "\n".join(lines) + "\n" + summary + "\n"
print(table)
if args.out:
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write(f"# Retrieval evaluation ({args.tool}, k={args.k})\n\n{table}")
    print(f"Wrote {args.out}")
