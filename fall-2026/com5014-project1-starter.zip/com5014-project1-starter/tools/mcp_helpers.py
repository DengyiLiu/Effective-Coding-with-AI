"""Small helpers shared by check_server.py, retrieval_eval.py and the tests.

They start your server as a separate process (exactly like Claude Code or Codex does)
and talk to it over MCP. No LLM is involved.
"""
import asyncio
import json
import sys
from pathlib import Path

from mcp import Client, StdioServerParameters

ROOT = Path(__file__).resolve().parent.parent


def params(server_file: str) -> StdioServerParameters:
    path = Path(server_file)
    if not path.is_absolute():
        path = ROOT / path
    return StdioServerParameters(command=sys.executable, args=[str(path)], cwd=str(ROOT))


def result_data(result):
    """Turn a tool result into Python data (list/dict/str)."""
    if getattr(result, "structured_content", None):
        data = result.structured_content
        # Functions returning a list are wrapped as {"result": [...]}
        if isinstance(data, dict) and set(data) == {"result"}:
            return data["result"]
        return data
    text = "".join(getattr(c, "text", "") for c in result.content)
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text


def result_text(result) -> str:
    return "".join(getattr(c, "text", "") for c in result.content)


def run(server_file: str, fn):
    """Open one MCP session to the server and run `await fn(client)` inside it."""
    async def _go():
        async with Client(params(server_file)) as client:
            return await fn(client)
    return asyncio.run(_go())
